-- Version information for TithesOfWar
return {
  version = '1.0.0',
  name = 'Tithe of War Quest Automation',
  author = 'Titheofwar',
  description = 'Complete quest automation framework for Tithe of War with manual pickup/turn-in',
  changelog = {
    ['1.0.0'] = 'Initial release - Full Tithe of War quest automation',
  },
}

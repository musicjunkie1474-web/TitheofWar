-- modules/parser.lua
-- Small parser utilities for interaction sequences
local M = {}

-- sequence is a list of { type='say'|'wait'|'hail'|'cmd', text=..., ms=... }
function M.execute(sequence)
  local ok, mq = pcall(require, 'mq')
  for _, step in ipairs(sequence or {}) do
    if step.type == 'say' and step.text then
      if ok and mq then mq.cmdf('/say %s', step.text) end
    elseif step.type == 'wait' and step.ms then
      if ok and mq and mq.delay then mq.delay(step.ms) end
    elseif step.type == 'hail' then
      if ok and mq then mq.cmd('/hail') end
    elseif step.type == 'cmd' and step.cmd then
      if ok and mq then mq.cmd(step.cmd) end
    end
  end
  return true
end

return M

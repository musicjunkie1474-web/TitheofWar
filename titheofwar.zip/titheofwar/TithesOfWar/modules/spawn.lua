-- modules/spawn.lua
-- Helpers for finding and interacting with spawns
local M = {}
local ok, mq = pcall(require, 'mq')

function M.findByName(name)
  if not ok or not mq then return nil end
  local s = mq.TLO.NearestSpawn(name)
  if s and s.ID and s.ID() ~= 0 then return s end
  return nil
end

return M

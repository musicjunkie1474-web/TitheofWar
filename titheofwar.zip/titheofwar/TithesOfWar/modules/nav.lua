-- modules/nav.lua
-- Lightweight nav module wrapper. Uses navigation.lua if present.
local M = {}
local navigation = (pcall(require, 'navigation') and require('navigation')) or nil

function M.moveTo(target)
  if navigation and navigation.moveTo then
    return navigation.moveTo(target)
  end
  return false, 'no-navigation-module'
end

return M

-- modules/group.lua
-- Minimal group utilities
local M = {}
local ok, mq = pcall(require, 'mq')

function M.isInGroup()
  if not ok or not mq then return false end
  return mq.TLO.Group.MainTank() ~= nil
end

return M

-- modules/inventory.lua
-- Thin wrapper over inventory functions
local M = {}
local ok, mq = pcall(require, 'mq')

function M.findItemByName(name)
  if not ok or not mq then return nil end
  local count = mq.TLO.FindItemCount(name)
  if count and count > 0 then return true end
  return false
end

return M

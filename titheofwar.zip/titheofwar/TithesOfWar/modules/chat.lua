-- modules/chat.lua
-- Simple chat utilities
local M = {}
local ok, mq = pcall(require, 'mq')

function M.say(text)
  if not ok or not mq then return false end
  mq.cmdf('/say %s', text)
  return true
end

function M.hail()
  if not ok or not mq then return false end
  mq.cmd('/hail')
  return true
end

return M

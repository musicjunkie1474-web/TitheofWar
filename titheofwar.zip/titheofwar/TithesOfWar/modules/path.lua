-- modules/path.lua
-- Placeholder for pathfinding helpers if needed
local M = {}

function M.follow(waypoints)
  -- expects a table of { {x=,y=,z=}, ... }
  for i=1,#waypoints do
    -- call global navigation
    if _G.TOW and _G.TOW.navigate_and_pause then
      _G.TOW:navigate_and_pause(waypoints[i])
    end
  end
  return true
end

return M

-- NPC helper functions (non-invasive, use when in MQ)
local M = {}

function M.findByName(name)
  if not name then return nil end
  local ok, mq = pcall(require, 'mq')
  if not ok or not mq or not mq.TLO then return nil end
  -- Try to find the nearest spawn with that name
  local spawn = mq.TLO.NearestSpawn(name)
  if spawn and spawn.ID and spawn.ID() ~= 0 then
    return spawn
  end
  return nil
end

function M.interactByName(name)
  local npc = M.findByName(name)
  if not npc then return false, 'not-found' end
  local ok, mq = pcall(require, 'mq')
  if not ok or not mq or not mq.cmd then return false, 'no-mq' end
  mq.cmdf('/target id %d', npc.ID())
  mq.delay(100)
  mq.cmd('/do emote interacts')
  return true
end

return M

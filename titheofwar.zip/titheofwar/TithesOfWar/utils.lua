local mq = require('mq')

local utils = {}

function utils.target(name)
    mq.cmdf("/target %s", name)
    mq.delay(500)
end

function utils.echo(msg)
    print("[TOW] "..msg)
end

return utils

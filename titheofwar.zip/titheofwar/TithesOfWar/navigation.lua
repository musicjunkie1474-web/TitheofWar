-- Navigation helpers with safe MQ travel support
local M = {}
local utils = pcall(require, 'utils') and require('utils') or nil
local cfg = pcall(require, 'data.config') and require('data.config') or nil
local defaultArrival = (cfg and cfg.arrivalDistance) or 10
local defaultNavTimeout = (cfg and cfg.navigationTimeout) or 60 -- seconds

local function safe_require_mq()
  local ok, mq = pcall(require, 'mq')
  if ok then return mq end
  return nil
end

local function current_zone_shortname(mq)
  if not mq or not mq.TLO or not mq.TLO.Zone then return nil end
  local ok, z = pcall(function() return mq.TLO.Zone.ShortName() end)
  if ok then return z end
  return nil
end

-- Accepts target as:
-- { x=, y=, z=, zone=optional }
-- or { zone = 'zonename' } to only travel zones
function M.moveTo(target)
  if type(target) ~= 'table' then return false, 'invalid-target' end
  local mq = safe_require_mq()
  if not mq then return true end -- outside MQ, assume success

  local arrival = target.arrivalDistance or defaultArrival
  local navTimeout = target.navigationTimeout or defaultNavTimeout

  -- If a zone is specified and different from current, attempt travel
  if target.zone then
    local cur = current_zone_shortname(mq)
    if cur ~= target.zone then
      -- Try to travel using /travelto <zone>
      mq.cmdf('/travelto %s', target.zone)
      -- Wait for zoning to start/finish
      local start = os.time()
      while os.time() - start < navTimeout do
        if mq.TLO.Me and mq.TLO.Me.Zoning and mq.TLO.Me.Zoning() then
          -- wait while zoning
        else
          local now = current_zone_shortname(mq)
          if now == target.zone then break end
        end
        mq.delay(500)
      end
      -- Recheck current zone
      local now = current_zone_shortname(mq)
      if now ~= target.zone then return false, 'travel-failed' end
      -- allow small delay after arrive
      mq.delay(1000)
    end
  end

  -- If coordinates provided, navigate within zone
  if target.x and target.y and target.z then
    -- Use TLO to check distance
    local start = os.time()
    while os.time() - start < navTimeout do
      local me = mq.TLO.Me
      if me and me.X and me.Y and me.Z then
        local mypos = { x = me.X(), y = me.Y(), z = me.Z() }
        local d = 0
        if utils and utils.distance then
          d = utils.distance(mypos, target)
        else
          d = math.sqrt((mypos.x - target.x)^2 + (mypos.y - target.y)^2 + (mypos.z - (target.z or 0))^2)
        end
        if d <= arrival then return true end
      end
      -- If navigation plugin/command exists, try to use it
      -- Prefer /nav target if target.name provided
      if target.name then
        mq.cmdf('/target %s', target.name)
        mq.delay(100)
        mq.cmd('/nav target')
      end
      mq.delay(500)
    end
    return false, 'timeout'
  end

  -- If only zone travel requested, success
  return true
end

return M

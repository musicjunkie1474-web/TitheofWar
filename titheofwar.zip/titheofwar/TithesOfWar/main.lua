-- Main entry (module-style) for TithesOfWar - Complete Quest Framework
-- Provides automated quest flow with manual pickup/turn-in for Tithe of War

local function safe_require(name)
  local ok, mod = pcall(require, name)
  if ok then return mod end
  return nil
end

local mq = safe_require('mq')
local logger = safe_require('logger') or { info = print, warn = print, error = print }
local config = safe_require('config') or {}
local utils = safe_require('utils')
local state = safe_require('state')
local navigation = safe_require('navigation')
local parser = safe_require('modules.parser')
local ui = safe_require('ui')
local version = safe_require('version') or { version = '1.0.0' }

local TOW = {}
TOW._enabled = false
TOW._running = true
TOW._state = state
TOW._version = version.version or '1.0.0'
TOW._quest_step = 'idle'

-- log helpers
local function log_info(...) if logger and logger.info then logger.info(table.concat({...}, ' ')) end end
local function log_warn(...) if logger and logger.warn then logger.warn(table.concat({...}, ' ')) end end
local function log_error(...) if logger and logger.error then logger.error(table.concat({...}, ' ')) end end

-- Load and merge data from data/*.lua
local function load_data_module(name)
  local ok, mod = pcall(require, name)
  if ok and type(mod) == 'table' then return mod end
  return nil
end

local function unload_module(name)
  if package and package.loaded and package.loaded[name] then
    package.loaded[name] = nil
  end
end

local function merge_into(dest, src)
  if not src then return end
  for k, v in pairs(src) do dest[k] = v end
end

local function do_load_data()
  local data_config = load_data_module('data.config')
  local data_npcs = load_data_module('data.npcs')
  local data_zones = load_data_module('data.zones')
  local data_items = load_data_module('data.items')

  TOW.data = TOW.data or {}
  TOW.data.npcs = data_npcs or TOW.data.npcs or {}
  TOW.data.waypoints = (data_config and data_config.waypoints) or TOW.data.waypoints or {}
  TOW.data.items_of_interest = (data_items and data_items.items) or TOW.data.items_of_interest or {}
  TOW.data.zones = data_zones or TOW.data.zones or {}
end

local function sanitize(s)
  if not s then return '' end
  local v = tostring(s):lower()
  v = v:gsub('[^%w]', '')
  return v
end

local function get_zone_shortname()
  if mq and mq.TLO and mq.TLO.Zone and mq.TLO.Zone.ShortName then
    local ok, z = pcall(function() return mq.TLO.Zone.ShortName() end)
    if ok and z then return z end
  end
  return nil
end

local function merge_zone_waypoints()
  local zone_short = get_zone_shortname()
  local zone_def = nil

  if zone_short and TOW.data.zones and TOW.data.zones[zone_short] then
    zone_def = TOW.data.zones[zone_short]
  end

  if zone_def and zone_def.waypoints then
    log_info('[TOW] applying waypoints for zone:', zone_short)
    merge_into(TOW.data.waypoints, zone_def.waypoints)
    TOW.data.current_zone = zone_short
    return true
  end
  return false
end

local function validate_data()
  if not TOW.data.npcs then
    log_warn('[TOW] data.npcs missing; using empty')
  end
  if not TOW.data.zones or next(TOW.data.zones) == nil then
    log_warn('[TOW] data.zones empty; add zones in data/zones.lua')
  end
end

function TOW:reload_data()
  unload_module('data.config')
  unload_module('data.npcs')
  unload_module('data.zones')
  unload_module('data.items')
  do_load_data()
  merge_zone_waypoints()
  validate_data()
  log_info('[TOW] data reloaded')
  return true
end

-- Initial load
do_load_data()
merge_zone_waypoints()
validate_data()

function TOW:start()
  if self._enabled then
    log_warn('[TOW] already started')
    return false
  end
  self._enabled = true
  self._quest_step = 'step1_zayenaekk_poj'
  log_info('[TOW] enabled - quest started at step 1')
  return true
end

function TOW:stop()
  if not self._enabled then
    log_warn('[TOW] already stopped')
    return false
  end
  self._enabled = false
  self._quest_step = 'idle'
  log_info('[TOW] disabled')
  return true
end

function TOW:status()
  return {
    enabled = self._enabled,
    state = (self._state and self._state.get and self._state.get()) or 'unknown',
    version = self._version,
    quest_step = self._quest_step,
  }
end

-- Navigate to a named NPC step and optionally perform interactions
function TOW:navigate_to_step(step_name)
  local npc_entry = (self.data and self.data.npcs and self.data.npcs[step_name]) or nil
  if not npc_entry then
    log_warn('[TOW] step not found:', step_name)
    return false, 'step-not-found'
  end

  log_info('[TOW] navigating to', step_name, '(zone:', npc_entry.zone, ')')

  if not navigation or not navigation.moveTo then
    log_warn('[TOW] navigation module not available')
    return false, 'no-navigation'
  end

  -- Build target with zone and coords
  local target = {
    zone = npc_entry.zone,
    x = npc_entry.coords and npc_entry.coords.x,
    y = npc_entry.coords and npc_entry.coords.y,
    z = npc_entry.coords and npc_entry.coords.z,
    name = npc_entry.name,
  }

  -- Navigate
  local ok, err = navigation.moveTo(target)
  if ok then
    log_info('[TOW] arrived at', step_name)
    self._quest_step = 'at_' .. step_name
    
    -- If manual pickup/turnin, stop here
    if npc_entry.manual_pickup or npc_entry.manual_turnin then
      self._enabled = false
      log_info('[TOW] manual action required at', step_name, '- paused')
      return true
    end

    -- Otherwise perform interactions if available
    if npc_entry.interactions and parser and parser.execute then
      log_info('[TOW] executing interactions for', step_name)
      parser.execute(npc_entry.interactions)
      log_info('[TOW] interactions complete for', step_name)
    end
    return true
  else
    log_warn('[TOW] navigation failed:', tostring(err))
    return false, err
  end
end

function TOW:navigate_to_murdunk_sword()
  return self:navigate_to_step('murdunk_sword')
end

-- Main tick loop
function TOW:_tick()
  if not self._enabled then
    self._quest_step = 'idle'
    return
  end

  -- Minimal auto-flow (users can trigger via UI buttons)
  -- Step logic can be expanded here if auto-progression is desired
end

-- Graceful shutdown
function TOW:shutdown()
  self._running = false
  self._enabled = false
  log_info('[TOW] shutting down')
end

-- Expose globals for MQ console access
_G.TOW = TOW
_G.tow_start = function() return TOW:start() end
_G.tow_stop = function() return TOW:stop() end
_G.tow_status = function() local s = TOW:status(); for k,v in pairs(s) do print(k..":", tostring(v)) end return s end
_G.tow_reload = function() return TOW:reload_data() end
_G.tow_nav_sword = function() return TOW:navigate_to_murdunk_sword() end
_G.tow_nav_step = function(step) return TOW:navigate_to_step(step) end
_G.tow_ui_toggle = function() if ui and ui.toggle then ui.toggle() end end

-- Main loop (MQ only)
if mq and mq.delay then
  log_info('[TOW] starting persistent loop (Tithe of War v' .. TOW._version .. ')')
  while TOW._running do
    local ok, err = pcall(function() TOW:_tick() end)
    if not ok then log_error('[TOW] tick error:', tostring(err)) end

    -- Render UI each loop
    if ui and ui.render then
      local ok2, err2 = pcall(ui.render)
      if not ok2 then log_warn('[TOW] UI render error: ' .. tostring(err2)) end
    end

    mq.delay((config.loopDelay or 250))
  end
else
  log_info('[TOW] not in MQ; script loaded. Use TOW commands manually or call TOW:_tick().')
end

return TOW

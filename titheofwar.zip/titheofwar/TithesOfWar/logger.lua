local logger = {}

function logger.info(msg)
    print(string.format("\ag[TOW]\ax %s", msg))
end

function logger.warn(msg)
    print(string.format("\ay[TOW]\ax %s", msg))
end

function logger.error(msg)
    print(string.format("\ar[TOW]\ax %s", msg))
end

return logger

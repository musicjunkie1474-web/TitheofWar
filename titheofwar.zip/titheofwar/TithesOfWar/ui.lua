-- Optional ImGui UI for TithesOfWar
-- Provides a control window with Start/Stop, Reload Data, quest steps, and navigation
local M = {}

local function safe_require(name)
  local ok, mod = pcall(require, name)
  if ok then return mod end
  return nil
end

local ImGui = safe_require('ImGui')
local mq = safe_require('mq')

M.visible = false
M.confirmNavigate = false
M.confirmTarget = nil

function M.init()
  M.visible = false
  M.confirmNavigate = false
  M.confirmTarget = nil
  return true
end

function M.show()
  M.visible = true
end

function M.hide()
  M.visible = false
end

function M.toggle()
  M.visible = not M.visible
end

function M.render()
  if not M.visible then return end
  if not ImGui then return end

  local ok, err = pcall(function()
    ImGui.Begin('TithesOfWar')

    -- Status
    local tow = _G.TOW
    local status = tow and tow:status() or { enabled = false, state = 'unknown', version = 'unknown' }
    ImGui.Text(string.format('Enabled: %s', tostring(status.enabled)))
    ImGui.Text(string.format('State: %s', tostring(status.state)))
    ImGui.Text(string.format('Quest Step: %s', tostring(tow and tow._quest_step or 'idle')))
    ImGui.Text(string.format('Version: %s', tostring(status.version)))
    ImGui.Separator()

    -- Start/Stop
    if ImGui.Button(status.enabled and 'Stop' or 'Start', ImGui.ImVec2(100, 0)) then
      if tow then
        if status.enabled then tow:stop() else tow:start() end
      end
    end
    ImGui.SameLine()
    if ImGui.Button('Reload Data', ImGui.ImVec2(100, 0)) then
      if tow and tow.reload_data then tow:reload_data() end
    end

    ImGui.Separator()
    ImGui.Text('Quest Navigation:')

    -- Quest step buttons
    if ImGui.Button('Go to Zayenaekk (Plane of Justice)', ImGui.ImVec2(-1, 0)) then
      M.confirmNavigate = true
      M.confirmTarget = 'zayenaekk_poj'
    end
    if ImGui.Button("Go to Murdunk's Sword (Plane of Earth)", ImGui.ImVec2(-1, 0)) then
      M.confirmNavigate = true
      M.confirmTarget = 'murdunk_sword'
    end
    if ImGui.Button('Go to Murdunk (Korascian Warrens)', ImGui.ImVec2(-1, 0)) then
      M.confirmNavigate = true
      M.confirmTarget = 'murdunk'
    end
    if ImGui.Button('Go to Etsinthinikonarifet (Plane of War)', ImGui.ImVec2(-1, 0)) then
      M.confirmNavigate = true
      M.confirmTarget = 'etsinthinikonarifet'
    end

    ImGui.Separator()

    -- Confirmation modal
    if M.confirmNavigate then
      ImGui.OpenPopup('Confirm Navigation')
      M.confirmNavigate = false
    end

    if ImGui.BeginPopupModal('Confirm Navigation', true) then
      ImGui.Text('Navigate to ' .. tostring(M.confirmTarget) .. '?')
      ImGui.Text('Manual pickup and turn-in required for quest items.')
      ImGui.Separator()

      if ImGui.Button('Confirm', ImGui.ImVec2(100, 0)) then
        if tow then
          if M.confirmTarget == 'zayenaekk_poj' then
            tow:navigate_to_step('zayenaekk_poj')
          elseif M.confirmTarget == 'murdunk_sword' then
            tow:navigate_to_murdunk_sword()
          elseif M.confirmTarget == 'murdunk' then
            tow:navigate_to_step('murdunk')
          elseif M.confirmTarget == 'etsinthinikonarifet' then
            tow:navigate_to_step('etsinthinikonarifet')
          end
        end
        M.confirmTarget = nil
        ImGui.CloseCurrentPopup()
      end
      ImGui.SameLine()
      if ImGui.Button('Cancel', ImGui.ImVec2(100, 0)) then
        M.confirmTarget = nil
        ImGui.CloseCurrentPopup()
      end
      ImGui.EndPopupModal()
    end

    ImGui.Separator()
    ImGui.Text('Notes:')
    ImGui.TextWrapped('- Manual pickup and turn-in enabled by default')
    ImGui.TextWrapped('- Scribe and tribute creation are manual steps')

    ImGui.End()
  end)
  if not ok then
    print('[TOW][UI] render error: ' .. tostring(err))
  end
end

return M

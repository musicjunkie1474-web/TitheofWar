local config = {}

config.debug = true
config.chaseDistance = 25
config.pauseOnCombat = false

return config

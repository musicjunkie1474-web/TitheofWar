-- Event handling helpers (lightweight)
local M = {}
M.handlers = {}

function M.on(name, fn)
  if not name or type(fn) ~= 'function' then return end
  M.handlers[name] = M.handlers[name] or {}
  table.insert(M.handlers[name], fn)
end

function M.emit(name, ...)
  if not name then return end
  local list = M.handlers[name]
  if not list then return end
  for _, fn in ipairs(list) do
    local ok, err = pcall(fn, ...)
    if not ok then
      local logger = pcall(require, 'logger') and require('logger') or nil
      if logger and logger.error then logger.error('Event handler error:', err) end
    end
  end
end

-- Optional helper that attempts to hook MQ events if available.
function M.attachMQ()
  local ok, mq = pcall(require, 'mq')
  if not ok or not mq or not mq.event then return false end
  -- MQ's event API varies; leave this as a manual integration point.
  return true
end

return M

-- Inventory helpers
local M = {}

function M.countItem(nameOrId)
  local ok, mq = pcall(require, 'mq')
  if not ok or not mq or not mq.TLO then return 0 end
  -- Try to use TLO.FindItemCount if available, else fall back to scanning
  local count = 0
  local ok2, t = pcall(function() return mq.TLO.FindItemCount(nameOrId) end)
  if ok2 and type(t) == 'number' then return t end

  -- Fallback: iterate inventory
  local inv = mq.TLO.Me and mq.TLO.Me.Inventory and mq.TLO.Me.Inventory() or nil
  if inv then
    for i = 1, inv.Count() do
      local it = inv[i]
      if it and (it.Name() == nameOrId or tostring(it.ID()) == tostring(nameOrId)) then
        count = count + it.StackCount()
      end
    end
  end
  return count
end

function M.hasItem(nameOrId)
  return M.countItem(nameOrId) > 0
end

return M

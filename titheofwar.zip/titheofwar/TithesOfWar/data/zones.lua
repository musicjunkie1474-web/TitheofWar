-- Zone data for TithesOfWar - Tithe of War Quest
-- Complete zone information with waypoints for each quest step
return {
  plane_of_justice = {
    name = "Plane of Justice",
    shortname = "plane_of_justice",
    npcs = { "Zayenaekk" },
    waypoints = {
      start = { x = -280, y = -380, z = 100 },
      zayenaekk = { x = -350, y = -400, z = 95 },
    },
  },

  korascian_warrens = {
    name = "Korascian Warrens",
    shortname = "korascian_warrens",
    npcs = { "Murdunk" },
    waypoints = {
      start = { x = -500, y = -100, z = 10 },
      murdunk = { x = -480, y = -120, z = 8 },
    },
  },

  plane_of_earth = {
    name = "Plane of Earth A",
    shortname = "plane_of_earth",
    npcs = { "Murdunk's Sword" },
    waypoints = {
      start = { x = 0, y = 0, z = -50 },
      -- Murdunk's Sword ground spawn coordinates provided by user
      sword = { x = -1999.49, y = -114.75, z = 55.81 },
    },
  },

  toskirakk = {
    name = "Toskirakk",
    shortname = "toskirakk",
    npcs = { "Zayenaekk" },
    waypoints = {
      start = { x = 500, y = 300, z = -30 },
      zayenaekk = { x = 520, y = 320, z = -25 },
    },
  },

  plane_of_war = {
    name = "Plane of War",
    shortname = "plane_of_war",
    npcs = { "Etsinthinikonarifet" },
    waypoints = {
      start = { x = 100, y = 200, z = 0 },
      etsinthinikonarifet = { x = 150, y = 250, z = 5 },
    },
  },
}

-- Data-driven defaults for TithesOfWar
-- This file is intended to be edited by the user or kept as reference defaults.
return {
  waypoints = {
    -- example: { name = 'start', x = 100, y = 200, z = 5 }
  },
  npcs = {
    -- example NPC lists for the Plane of War
    quest_givers = {},
    vendors = {},
  },
  items = {
    -- example item definitions
  },

  -- Behavior flags
  auto_pickup = false,    -- do not auto-pick ground spawns by default
  auto_turnin = false,    -- do not auto-turnin quest items by default
  loopDelay = 250,        -- ms between main loop ticks
  arrivalDistance = 10,   -- distance considered "arrived" at a waypoint
  navigationTimeout = 60, -- seconds to wait for travel/navigation to complete
}

-- Item definitions for TithesOfWar - Tithe of War Quest
-- Replace with real item IDs and names as needed for quest rewards/items
return {
  items = {
    { id = 0, name = "Tithe Token" },
    { id = 0, name = "Blessing Book" },
    { id = 0, name = "Mark of Zayenaekk" },
  }
}

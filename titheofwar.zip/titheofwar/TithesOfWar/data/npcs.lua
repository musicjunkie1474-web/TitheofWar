-- NPC definitions for TithesOfWar - Tithe of War Quest
-- Complete quest flow with all NPC interactions and waypoints
return {
  -- Step 1: Zayenaekk in Plane of Justice
  zayenaekk_poj = {
    name = "Zayenaekk",
    zone = "plane_of_justice",
    coords = { x = -350, y = -400, z = 95 },
    interactions = {
      { type = 'say', text = 'za ye na ekk' },
      { type = 'wait', ms = 1000 },
      { type = 'say', text = 'ets in thini konar ifet' },
    },
    step = 1,
    notes = 'First interaction with Zayenaekk',
  },

  -- Step 2: Murdunk in Korascian Warrens
  murdunk = {
    name = "Murdunk",
    zone = "korascian_warrens",
    coords = { x = -480, y = -120, z = 8 },
    interactions = {
      { type = 'hail' },
      { type = 'wait', ms = 1000 },
      { type = 'say', text = 'i seek an audience with zayenaekk' },
    },
    step = 2,
    notes = 'Requires Ogre language set; skill >= 90 (manual requirement)',
  },

  -- Step 3: Ground spawn - Murdunk's Sword (Plane of Earth A)
  murdunk_sword = {
    name = "Murdunk's Sword",
    zone = "plane_of_earth",
    type = 'ground_spawn',
    coords = { x = -1999.49, y = -114.75, z = 55.81 },
    step = 3,
    manual_pickup = true,
    notes = 'Player will pick up the sword manually and turn in to Murdunk',
  },

  -- Step 4: Etsinthinikonarifet in Plane of War (tribute turn-in)
  etsinthinikonarifet = {
    name = "Etsinthinikonarifet",
    zone = "plane_of_war",
    coords = { x = 150, y = 250, z = 5 },
    interactions = {
      { type = 'say', text = 'ets in thini konar ifet' },
    },
    step = 7,
    manual_turnin = true,
    notes = 'Turn in tribute (player creates it manually; tribute creation skipped)',
  },

  -- Step 5: Zayenaekk in Toskirakk
  zayenaekk_tos = {
    name = "Zayenaekk",
    zone = "toskirakk",
    coords = { x = 520, y = 320, z = -25 },
    interactions = {
      { type = 'say', text = 'i seek the blessing of your sister' },
    },
    step = 5,
    notes = 'Right-click and scribe the book manually (no tradeskill automation)',
  },

  -- Convenience mappings for backwards compatibility
  quest_giver = "Zayenaekk",
  looter = "Etsinthinikonarifet",
}

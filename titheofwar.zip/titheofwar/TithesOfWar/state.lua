-- Simple state management for the framework
local M = {}

M.states = {
  idle = 'idle',
  navigating = 'navigating',
  questing = 'questing',
  combat = 'combat',
  looting = 'looting',
}

M.current = M.states.idle

function M.set(state)
  if not state then return end
  M.current = state
end

function M.get()
  return M.current
end

function M.is(state)
  return M.current == state
end

return M
